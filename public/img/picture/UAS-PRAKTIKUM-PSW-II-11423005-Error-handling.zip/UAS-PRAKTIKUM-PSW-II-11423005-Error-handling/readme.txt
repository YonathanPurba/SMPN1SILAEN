Name Of DataBase : db_booking_lapangan
localhost : 3307
username  : root
password  :

Username & Password
* Admin
- Username : admin
- Password : admin

* User
- Username : Pak Oppir
- Password : Baik Hati

ENV file ada di
.env.example hapus ".example" nya
